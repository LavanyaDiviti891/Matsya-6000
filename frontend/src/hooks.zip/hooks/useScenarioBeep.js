import { useEffect, useRef } from "react";

/**
 * useScenarioBeep — audible-only reaction to appState.co2_scenario.beep_level.
 * Covers BOTH alarm points in the combined CO2 -> navigation-instability ->
 * emergency-buoy mission:
 *   "critical" -> continuous beep, until it clears
 *   ""          -> silent
 * There is intentionally NO visual pop-up/banner/flashing element here --
 * `co2_scenario.feedback_msg` still carries the plain-text instruction for
 * whatever already displays it; this hook only ever makes sound.
 *
 * Usage in App.jsx:
 *   import { useScenarioBeep } from './hooks/useScenarioBeep'
 *   ...
 *   useScenarioBeep(appState)   // call unconditionally, alongside the other hooks
 */
export function useScenarioBeep(appState) {
  const audioCtxRef = useRef(null);
  const oscillatorRef = useRef(null);
  const gainRef = useRef(null);
  const prevLevelRef = useRef("");

  const getCtx = () => {
    if (!audioCtxRef.current) {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      audioCtxRef.current = new AudioCtx();
    }
    return audioCtxRef.current;
  };

  const stopContinuous = () => {
    if (oscillatorRef.current) {
      try {
        oscillatorRef.current.stop();
      } catch (e) {
        /* already stopped */
      }
      oscillatorRef.current.disconnect();
      oscillatorRef.current = null;
    }
    if (gainRef.current) {
      gainRef.current.disconnect();
      gainRef.current = null;
    }
  };

  const startContinuous = (freq = 880) => {
    stopContinuous();
    const ctx = getCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "square";
    osc.frequency.value = freq;
    gain.gain.value = 0.08;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    oscillatorRef.current = osc;
    gainRef.current = gain;
  };

  const playSingleBeep = (freq = 660, durationMs = 220) => {
    const ctx = getCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = "sine";
    osc.frequency.value = freq;
    gain.gain.value = 0.1;
    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start();
    osc.stop(ctx.currentTime + durationMs / 1000);
  };

  useEffect(() => {
    const level = appState?.co2_scenario?.beep_level || "";
    const prevLevel = prevLevelRef.current;

    if (level === "critical") {
      if (prevLevel !== "critical") {
        startContinuous(880);
      }
    } else {
      stopContinuous();
      if (level === "warning" && prevLevel !== "warning") {
        playSingleBeep(660, 220);
      }
    }

    prevLevelRef.current = level;
  }, [appState?.co2_scenario?.beep_level]);

  useEffect(() => {
    return () => {
      stopContinuous();
      if (audioCtxRef.current) {
        audioCtxRef.current.close();
      }
    };
  }, []);
}
